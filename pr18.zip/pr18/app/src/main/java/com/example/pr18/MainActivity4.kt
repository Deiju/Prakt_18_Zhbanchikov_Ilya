package com.example.pr18

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity4 : AppCompatActivity() {
    lateinit var button:Button
    lateinit var butto:Button
    lateinit var text:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        button=findViewById(R.id.button1)
        butto=findViewById(R.id.button2)
        text=findViewById(R.id.text)
        button.setOnClickListener {
            val intent = Intent(this@MainActivity4, MainActivity3::class.java)
            startActivity(intent)
        }
        butto.setOnClickListener {
            var name:String=intent.getStringExtra("name").toString()
            text.setText(name)
        }
    }
}