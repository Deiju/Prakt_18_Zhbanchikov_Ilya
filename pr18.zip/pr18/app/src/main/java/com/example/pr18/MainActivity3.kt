package com.example.pr18

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.google.gson.Gson

class MainActivity3 : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private var spinn: Spinner ?=null
    lateinit var button: Button
    lateinit var butto: Button
    lateinit var butt: Button
    lateinit var edits:EditText
    lateinit var text:TextView
    lateinit var items:String
    var kurs:Double=0.0
    var list= arrayOf("Доллар","Евро","Тенге","Турецкие лиры")
    private var arradapt: ArrayAdapter<String>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        button=findViewById(R.id.button)
        spinn=findViewById(R.id.spin)
        edits=findViewById(R.id.edit3)
        butto=findViewById(R.id.button1)
        butt=findViewById(R.id.button2)
        text=findViewById(R.id.text3)
        arradapt= ArrayAdapter(applicationContext,android.R.layout.simple_spinner_item,list)
        spinn?.adapter=arradapt
        spinn?.onItemSelectedListener=this
        button.setOnClickListener {
        if(edits.getText().toString().trim().length>0)
        {
            if(items=="Доллар")
            {
                kurs= Math.round((Integer.parseInt(edits.getText().toString())*81.18)*100)/100.toDouble()
                text.setText(kurs!!.toString())
            }
            if(items=="Евро")
            {
                kurs= Math.round((Integer.parseInt(edits.getText().toString())*88.98)*100)/100.toDouble()
                text.setText(kurs!!.toString())
            }
            if(items=="Тенге")
            {
                kurs= Math.round((Integer.parseInt(edits.getText().toString())*0.18)*100)/100.toDouble()
                text.setText(kurs!!.toString())
            }
            if(items=="Турецкие лиры")
            {
                kurs= Math.round((Integer.parseInt(edits.getText().toString())*4.16)*100)/100.toDouble()
                text.setText(kurs!!.toString())
            }
        }
            else{
            Toast.makeText(this,"Пустое поле",Toast.LENGTH_SHORT).show()
        }
        }
        butto.setOnClickListener {
            if(edits.getText().toString().trim().length>0)
            {
                val name:String=items+" "+edits+" "+kurs+" "+"Рублей"
                val js:String= Gson().toJson(name)
                intent.putExtra("name",js)
            }
            else
            {
                Toast.makeText(this,"Пустое поле",Toast.LENGTH_SHORT).show()
            }
        }
        butt.setOnClickListener {
            val intent = Intent(this@MainActivity3, MainActivity4::class.java)
            startActivity(intent)
        }
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        items=parent?.getItemAtPosition(position) as  String
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }


}